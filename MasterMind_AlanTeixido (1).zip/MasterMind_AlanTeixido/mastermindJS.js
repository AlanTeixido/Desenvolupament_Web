var colores = ["blanco", "amarillo", "azul", "negro", "rosa", "verde"];
var codigoSecreta = generarCodigoSecreta(); 

function generarCodigoSecreta() {
    var codigo = [];
    for (var i = 0; i < 4; i++) {
        var colorIndex = Math.floor(Math.random() * colores.length);
        codigo.push(colores[colorIndex]);
    }
    return codigo;
}

function crearCirculo(color) {
    var circle = document.createElement("div");
    circle.className = "color-circle";
    circle.style.backgroundColor = color;
    return circle;
}

function inicializarTablero() {
    var tabla = document.getElementById("game-board");
    for (var i = 0; i < 10; i++) {
        var fila = document.createElement("tr");
        for (var j = 0; j < 4; j++) {
            var celda = document.createElement("td");
            var circle = crearCirculo("gray"); // Círculo gris por defecto
            celda.appendChild(circle);
            fila.appendChild(celda);
        }
        tabla.appendChild(fila);
    }
}

function actualizarTablero(fila, intento) {
    for (var i = 0; i < 4; i++) {
        var celda = fila.children[i];
        var circle = celda.firstChild;
        circle.style.backgroundColor = intento[i];
    }
}

document.addEventListener("DOMContentLoaded", function () {
    inicializarTablero();

    var filas = document.getElementById("game-board").getElementsByTagName("tr");

    for (var i = 0; i < filas.length; i++) {
        filas[i].addEventListener("click", function () {
            // Aquí debes implementar la lógica del juego al hacer clic en una fila
            // Puedes permitir que el jugador elija colores y comparar con la combinación secreta
            // Luego, actualiza el tablero llamando a la función actualizarTablero
        });
    }
});
